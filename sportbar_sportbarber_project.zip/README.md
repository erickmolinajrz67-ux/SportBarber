Sport Barber — Next.js Booking App
=================================

Proyecto listo para desplegar en Vercel. Reemplaza las variables de entorno en .env.local con tus claves de Firebase antes de desplegar.
